import java.io.*;

public class CopyFilesToNewFolder {
    public static void main(String[] args) throws IOException {
        File[]Folders=ReadFolder.Read("D:\\Thesis 2\\Complete DataSet\\5 folders rename - Copy");
        File destFile = new File("D:\\Thesis 2\\Complete DataSet\\DataSet");
        for(File file:Folders) {
        File sourceFile = file;
        System.out.println(sourceFile);
        System.out.println("");
        System.out.println(destFile);
         copyFiles(sourceFile,destFile);
            }
        }
   public static void copyFiles(File sourceLocation , File targetLocation)
    throws IOException {

        if (sourceLocation.isDirectory()) {
            if (!targetLocation.exists()) {
                targetLocation.mkdir();
            }
            File[] files = sourceLocation.listFiles();
            for(File file:files){
                InputStream in = new FileInputStream(file);
                OutputStream out = new FileOutputStream(targetLocation+"/"+file.getName());

                // Copy the bits from input stream to output stream
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
            }            
        }
}
}