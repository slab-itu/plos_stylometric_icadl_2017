import java.io.*;

public class RenameFile {
    public static void main(String[] args) {
//        String absolutePath ="D:\\Thesis 2\\Complete DataSet\\New folder (2)";
//        File dir = new File(absolutePath);
//        File[] filesInDir = dir.listFiles();
//        int i = 9;
//        for(File file:filesInDir) {
//            i++;
//            String name = file.getName();
//            String Name ="AU_0" + i;
////              String m = name.replace(name,Name);
////              System.out.println( m);
//              String newPath = absolutePath + "\\" + Name;
//              file.renameTo(new File(newPath));
//              System.out.println(name + " changed to " + Name);
//        }

String File1="D:\\Thesis 2\\Complete DataSet\\New folder (2)";
        File[]Folders=ReadFolder.Read(File1);
        int i=203;
//        int x=17;
//        int count = 0;        
        for(File file:Folders){
//               count ++;
//               if ( count==x)
//               {x=x+16;
//                i++;
//        }
              String name = file.getName();
//            System.out.println(name);
              String newname =name.substring(name.indexOf("_")+1);
                String[] parts = newname.split("_", 3);
                String front = parts[1]+"_"+parts[2];
//              System.out.println(front);
                String Name ="AU" + i+"_"+front;
                String newPath = File1 + "\\" + Name;
                file.renameTo(new File(newPath));
                System.out.println(Name);    
//                if(count==21)
//                break;
        }
    }
}