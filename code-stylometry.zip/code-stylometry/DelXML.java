
import java.io.File;
import java.io.IOException;


public class DelXML {
    public static void main(String[]args) throws IOException{
    String File1="D:\\Thesis 2\\Complete DataSet\\2 xml to txt only body - Copy";
        File[]Folders=ReadFolder.Read(File1);
        for(File Folder:Folders){
File folder = new File(Folder.toString());
File[] listOfFiles = folder.listFiles();
for(File f1:listOfFiles)
{if(f1.getName().endsWith(".xml")||f1.getName().endsWith(".XML"))
    f1.delete();
//    System.out.println(f1);

//System.out.println(filename);
   }
  }
 }
}

      
