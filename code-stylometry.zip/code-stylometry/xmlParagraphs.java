//Read xml single file and convert to txt

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class xmlParagraphs {
    public static void main (String[]args) throws IOException, Exception{
        String Folder="D:\\Thesis 2\\Complete DataSet\\3 Without xmls - Copy";
        File[]Folders1=ReadFolder.Read(Folder);
         for (File file1 : Folders1){
        File[]Folders=ReadFolder.Read(file1.toString());{
//        for(int i=0;i<Folders.length;i++)
        for (File file : Folders)
        {String File=file.toString();
//        String File=File1;
        String text1=FileRead.readFrom(File);
        System.out.println(File);
        String newString = text1.replaceAll("(?s)<italic[^>]*>.*?</italic>","");
        newString=newString.replaceAll("(?s)<xref[^>]*>.*?</xref>","");
        newString=newString.replaceAll("(?s)<ext-link[^>]*>.*?</ext-link>","");
//        newString=newString.replaceAll("(?s)<named-content[^>]*>.*?</named-content>","");
//        newString=newString.replaceAll("(?s)<email[^>]*>.*?</email>","");
//        newString=newString.replaceAll("(?s)<sub[^>]*>.*?</sub>","");
//        newString=newString.replaceAll("(?s)</disp-formula[^>]*>.*?<//disp-formula>","");
//        newString=newString.replaceAll("(?s)</sup[^>]*>.*?<//sup>","");
//        newString=newString.replaceAll("(?s)</inline-formula[^>]*>.*?<//inline-formula>","");
//        newString = newString.replaceAll("\\<.*?\\>", "");
        String output=Arrays.toString(getTagValues(newString).toArray());
        String tagless = output.replaceAll("\\<.*?\\>", "");
//        System.out.println("TAGLESS:\n\t" + tagless);
        String OutFile=File+".txt";
        SaveOutPutasText.OutPut(tagless,OutFile);
        
        }
    }
  }
    }
private static final Pattern TAG_REGEX = Pattern.compile("<p>(.+?)</p>");
private static List<String> getTagValues(final String str) {
    final List<String> tagValues = new ArrayList<String>();
    final Matcher matcher = TAG_REGEX.matcher(str);
    while (matcher.find()) {
        
        tagValues.add(matcher.group(1));
        tagValues.toString().replaceAll("<\\/?[bi]>", "");  
    }
    return tagValues;
}

}