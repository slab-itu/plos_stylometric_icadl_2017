import java.io.*;
public class SaveOutPutasText
{
   public static void OutPut(String Data,String File1)throws Exception
    {
        SaveOutPutasText t = new SaveOutPutasText();
        File f = new File(File1);
        FileOutputStream fos = new FileOutputStream(f);
        PrintWriter pw = new PrintWriter(fos);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
//        System.out.println("Enter a text: ");
        String str = Data;
        pw.write(str);
        pw.flush();
        fos.close();
        pw.close();
    }
}
