import java.io.File;
public class GetXML {
 public static void main(String[] args) {
File folder = new File("D:\\Thesis 2\\Complete DataSet\\try\\2 Aksoy Serap");
File[] listOfFiles = folder.listFiles();
for(int i = 0; i < listOfFiles.length; i++){
String filename = listOfFiles[i].getName();
if(filename.endsWith(".xml")||filename.endsWith(".XML"))
{
System.out.println(filename);
}
   }
  }
 }