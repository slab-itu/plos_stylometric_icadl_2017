import java.io.IOException;
import java.io.PrintWriter;
public class OutputtextFile {
    public static void main(String[]args) throws IOException{
        int[]x={1,2,3,4,5,6,7,8,4,2};
   try
{
    PrintWriter pr = new PrintWriter("E:\\Tehreem\\ITU\\3rd Semester\\Thesis\\Data\\Out.txt");    
    for (int i=0; i<x.length ; i++)
    {
        pr.println(x[i]);
    }
    pr.close();
}
catch (Exception e)
{
    e.printStackTrace();
    System.out.println("No such file exists.");
}
}
}

