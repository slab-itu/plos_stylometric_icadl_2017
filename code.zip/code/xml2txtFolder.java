//Read Folder Convert each xml to txt
import java.io.File;
import java.io.IOException;

public class xml2txtFolder {
    public static void main (String[]args) throws IOException, Exception{
        String File1="D:\\Thesis 2\\Complete DataSet\\xml_new - Copy";
        File[]Folders=ReadFolder.Read(File1);
        for(File Folder:Folders){
//            System.out.print(Folder.toString());
        File[]Files=ReadFolder.Read(Folder.toString());
        for(File file:Files)
//            System.out.print(file.toString());
        {String File=file.toString();
        String text1=FileRead.readFrom(File);
        System.out.println("-----------text--------");
       // System.out.println(text1);
        String tagful = text1;
    //String tagful = "Hello <fizz>buzz</fizz>Regexes!";
    String tagless = tagful.replaceAll("\\<.*?\\>", "");
    System.out.println("TAGLESS:\n\t" + tagless);
    String OutFile=file+".txt";
    SaveOutPutasText.OutPut(tagless,OutFile);
    }
  }
 } 
}