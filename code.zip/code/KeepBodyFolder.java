//Read Folder Convert each xml to txt
import java.io.File;
import java.io.IOException;

public class KeepBodyFolder {
    public static void main (String[]args) throws IOException, Exception{
        String Folder="D:\\Thesis 2\\Complete DataSet\\1 xml_new - Copy";
        File[]Folders1=ReadFolder.Read(Folder);
         for (File file1 : Folders1){
        File[]Folders=ReadFolder.Read(file1.toString());{
        for (File file : Folders)
        {String File=file.toString();
        String text1=FileRead.readFrom(File);
        String newString = text1.replaceAll("(?s)<front[^>]*>.*?</front>","");
        newString=newString.replaceAll("(?s)<back[^>]*>.*?</back>","");
        newString = newString.replaceAll("<!DOCTYPE((.|\n|\r)*?)\">", "");
//        newString=newString.replaceAll("(?s)<table-wrap[^>]*>.*?</table-wrap>","");
        newString=newString.replaceAll("(?s)<xref[^>]*>.*?</xref>","");
        newString=newString.replaceAll("(?s)<object-id[^>]*>.*?</object-id>","");
        newString=newString.replaceAll("(?s)<ext-link[^>]*>.*?</ext-link>","");
        String tagless = newString.replaceAll("\\<.*?\\>", "");

        CharSequence result=trimTrailingWhitespace(tagless);
        
        System.out.println("TAGLESS:\n\t" + result);     
        String OutFile=File+".txt";
        SaveOutPutasText.OutPut((String) result,OutFile);
        
               }
            }
         }
    
    }
    public static CharSequence trimTrailingWhitespace(CharSequence source) {

    if(source == null)
        return "";

    int i = source.length();
    while(--i >= 0 && Character.isWhitespace(source.charAt(i))) {
    }

    return source.subSequence(0, i+1);
}
}

