//Read xml single file and convert to txt
import java.io.IOException;


public class KeepBodySingleFile {
    public static void main (String[]args) throws IOException, Exception{
        String File1="D:\\Thesis 2\\Complete DataSet\\3 Without xmls - Copy\\2 Aksoy Serap\\10.1371 journal.pntd.0000662.XML";
        String File=File1+".xml";
        String text1=FileRead.readFrom(File);
        String newString = text1.replaceAll("(?s)<front[^>]*>.*?</front>","");
        newString=newString.replaceAll("(?s)<back[^>]*>.*?</back>","");
        newString = newString.replaceAll("<!DOCTYPE((.|\n|\r)*?)\">", "");
//        newString=newString.replaceAll("(?s)<table-wrap[^>]*>.*?</table-wrap>","");
        newString=newString.replaceAll("(?s)<xref[^>]*>.*?</xref>","");
        newString=newString.replaceAll("(?s)<object-id[^>]*>.*?</object-id>","");
        newString=newString.replaceAll("(?s)<ext-link[^>]*>.*?</ext-link>",""); 
          String tagless = newString.replaceAll("\\<.*?\\>", "");
//        tagless = tagless.replaceAll("[\n\r]+", "\n");
//        tagless = tagless.replaceAll("\n[ \t]*\n", "\n");
        CharSequence result=trimTrailingWhitespace(tagless);
         
        System.out.println("TAGLESS:\n\t" + result);     
        
        String OutFile=File1+".txt";
        SaveOutPutasText.OutPut((String) result,OutFile);
        
 
    }
    public static CharSequence trimTrailingWhitespace(CharSequence source) {

    if(source == null)
        return "";

    int i = source.length();

    // loop back to the first non-whitespace character
    while(--i >= 0 && Character.isWhitespace(source.charAt(i))) {
    }

    return source.subSequence(0, i+1);
}
        
}