//Read xml single file and convert to txt

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class xml2txt {
    public static void main (String[]args) throws IOException, Exception{
        String File1="E:\\Tehreem\\ITU\\4th Semester\\Thesis 2\\Try\\2 Aksoy Serap\\10.1371 journal.pntd.0000662";
        String File=File1+".xml";
        String text1=FileRead.readFrom(File);
//        String str1="<sec id=\"s1\">";
        String str = text1.replaceAll("<sec id=", "");
        str = text1.replaceAll("</sec>", "");
//         String newString = text1.replaceAll("(?s)<xref[^>]*>.*?</xref>","");
//        newString=newString.replaceAll("(?s)<object-id[^>]*>.*?</object-id>","");
//        newString=newString.replaceAll("(?s)<ext-link[^>]*>.*?</ext-link>","");
//        
String output=Arrays.toString(getTagValues(str).toArray());
//String output=Arrays.toString(getTagValues(newString).toArray());
//    String tagless = output.replaceAll("\\<.*?\\>", "");
//    System.out.println("TAGLESS:\n\t" + tagless);
        System.out.println("TAGLESS:\n\t" + output);

//String OutFile=File1+".txt";

//SaveOutPutasText.OutPut(tagless,OutFile);
    }
private static final Pattern TAG_REGEX = Pattern.compile("<body>(.+?)</body>");
private static List<String> getTagValues(final String str) {
    final List<String> tagValues = new ArrayList<String>();
    final Matcher matcher = TAG_REGEX.matcher(str);
    while (matcher.find()) {
        tagValues.add(matcher.group(1));
       }
    return tagValues;
}

}