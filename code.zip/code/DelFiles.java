import java.io.File;
 
public class DelFiles {
    public static void main(String[] args) {
        //Create File which you want to delete
        //File file = new File("E:\\Tehreem\\ITU\\4th Semester\\Thesis 2\\DataSet - Copy\\1\\AU009");
        String File1="D:\\Thesis 2\\Complete DataSet\\7 greater than 5 kb - Copy - Copy";
        File[]Folders=ReadFolder.Read(File1);
        for(File Folder:Folders)
            {  String filename = Folder.getName();
                if(!(filename.endsWith(".txt")||filename.endsWith(".TXT")))
                { boolean status = Folder.delete();
        if (status)
            System.out.println("File deleted successfully!!");
        else
            System.out.println("File name myfile.txt does not exists");
 
                }   
}
}
}