//Read Folder
import java.io.File;
public class ReadFolder {
//    public static void main (String[]args)
//    {String folder = ("E:\\Tehreem\\ITU\\4th Semester\\Thesis 2\\xml_new\\5 Attaran Amir");
//    Read(folder);
//    }
    public static File[]  Read(String Folder)
    {File folder = new File(Folder);
    File[] listOfFiles = folder.listFiles();
    for (File file : listOfFiles) {
    if (file.isFile()) {
//        System.out.println(file.getName());
    }
}
return listOfFiles;
}
static File[] Read(File Folder) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
