
import java.io.File;
import java.io.IOException;

public class RenameFolder {
    public static void main(String[]args) throws IOException{
    String File1="D:\\Thesis 2\\Complete DataSet\\4 File rename - Copy";
        File[]Folders=ReadFolder.Read(File1);
        for(File Folder:Folders){
             String fileName=Folder.getName();
             fileName = fileName.replace(".txt", "");
              int f=getFilesCount(Folder);
//             System.out.println(fileName);
//        }
//        String absolutePath = "D:\Thesis 2\Complete DataSet\3 Without xmls - Copy (2)";
        String absolutePath = Folder.toString();
        File dir = new File(absolutePath);
        File[] filesInDir = dir.listFiles();
        int i = 0;
        for(File file:filesInDir) {
            i++;
//            String name = file.getName();
          String newName = fileName+"_" + i +"_"+f+ ".txt";
//            String newName = fileName+"_"+f+ ".txt";
            String newPath = absolutePath + "\\" + newName;
            file.renameTo(new File(newPath));
   
//            System.out.println( newName);
        }
    }
    }
    public static int getFilesCount(File file) {
  File[] files = file.listFiles();
  int count = 0;
  for (File f : files)
    if (f.isDirectory())
      count += getFilesCount(f);
    else
      count++;

  return count;
}
}