DATA <- read.csv(file="D:/Tehreem Thesis/Complete DataSet/2/New folder/Unprocessed - Copy1-gram.csv", header=FALSE, sep=",")
mydata=Filter(function(x) !all(is.na(x)), DATA)
mydata
mydata=sim2dist(mydata, maxSim = 1)
mydata
# Ward Hierarchical Clustering
d <- dist(mydata, method = "euclidean") # distance matrix
fit <- hclust(d, method="ward") 
plot(fit) # display dendogram
groups <- cutree(fit, k=3) # cut tree into 5 clusters
# draw dendogram with red borders around the 5 clusters 
rect.hclust(fit, k=3, border="red")
