library(fpc)
for (x in 1:10) {
  tmp = paste("C:/Users/mtlab-01/Documents/NetBeansProjects/Stylometry/GramResults/New folder/Jacc-Preprocessed-Gram (",x, sep = "")
  tmp=paste(tmp,").csv", sep = "")
  DATA <- read.csv(file=tmp, header=FALSE, sep=",")
  out="C:/Users/mtlab-01/Documents/NetBeansProjects/Stylometry/GramResults/GRAPH-RESULTS.csv"
  #sink(out, append=FALSE, split=FALSE)
  mydata=Filter(function(x) !all(is.na(x)), DATA)
  mydata=sim2dist(mydata, maxSim = 1)
  X=kmeans(mydata,203)
  z=cluster.stats(mydata, X$cluster)
  InterC=z$average.between
  InterClust=round(InterC,digits=6)
  InteraC=z$average.within
  InteraClust=round(InteraC,digits=6)
  siIndex=z$sindex
  SilIndex=round(siIndex,digits=6)
  dun=z$dunn
  DunnIndex=round(dun,digits=6)
  dunn2=z$dunn2
  DunnIndex2=per(dunn2)
  SIN=z$sindex
  SeprationIndex=per(SIN)
  Gram=x
  tab=matrix()
  tab=cbind(Gram,InterClust,InteraClust,SilIndex,DunnIndex,DunnIndex2,SeprationIndex)
  print(tab)
  write.table(tab, file=out, sep=",", append=TRUE,row.names=FALSE,col.names=!file.exists(out))
  next
  #sink()
}

#closeAllConnections() 