for (x in 1:10) {
  tmp = paste("D:/Tehreem Thesis/Jaccard Dist mat/Jaccard-Preprocessed",x, sep = "")
  tmp=("C:/Users/mtlab-01/Documents/Tehreem-thesis/Jaccard-Unprocessed5-gram - Copy.csv")
  tmp=paste(tmp,"-gram.csv", sep = "")
  DATA <- read.csv(file=tmp, header=FALSE, sep=",")
  
  
  out="D:/Tehreem Thesis/Jaccard Dist mat/Jaccard-Preprocessed-hclust.csv"
  n=203
  mydata=Filter(function(x) !all(is.na(x)), DATA)
  mydata
  d <- dist(mydata, method = "euclidean") # distance matrix
  fit <- hclust(d, method="ward") 
  plot(fit) # display dendogram
  # Ward Hierarchical Clustering with Bootstrapped p values
  #install.packages("pvclust")
  library(pvclust)
  fit <- pvclust(mydata, method.hclust="ward",
                 method.dist="euclidean")
  plot(fit) # dendogram with p values
  
  ## hierarchical clustering
  d <- dist(mydata, method = "euclidean") # distance matrix
  fit <- hclust(d, method="ward") 
  library(clValid)
  nc <- n ## number of clusters      
  cluster <- cutree(fit,nc)
  DunnIndex=dunn(mydata, cluster)
  tab=matrix()
  Gram=x
  tab=cbind(Gram,DunnIndex)
  print(tab)
  write.table(tab, file=out, sep=",", append=TRUE,row.names=FALSE,col.names=!file.exists(out))
  next
}
