#Similarity to Distance matrrices in Folder
for (x in 1:10) {
  tmp = paste("C:/Users/mtlab-01/Documents/NetBeansProjects/Stylometry/GramResults/Jaccard/Preprocessed/Preprocessed",x, sep = "")
  tmp=paste(tmp,"-gram.csv", sep = "")
  DATA <- read.csv(file=tmp, header=FALSE, sep=",")
  out=paste("C:/Users/mtlab-01/Documents/NetBeansProjects/Stylometry/GramResults/Jaccard/Preprocessed/Distance matrices/Unprocessed",x, sep = "")
  out=paste(out,"-gram.csv", sep = "")
  #sink(out, append=FALSE, split=FALSE)
  mydata=Filter(function(x) !all(is.na(x)), DATA)
  mydata=sim2dist(mydata, maxSim = 1)
 
  m1=as.matrix(mydata)
  #print(mydata)
  write.table(m1, file=out, sep=",", append=FALSE,row.names=FALSE,col.names =FALSE )
 
  #sink()
next()
}

#closeAllConnections() 
