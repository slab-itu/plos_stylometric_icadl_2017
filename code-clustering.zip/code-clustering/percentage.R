per <- function(a){
  a=a*100
  a=ceiling(a)
  a = paste(a,"%", sep = "")
  return(a)
}